package metier;

public interface solving {
    public void solver();
    public double getsolde();

}
