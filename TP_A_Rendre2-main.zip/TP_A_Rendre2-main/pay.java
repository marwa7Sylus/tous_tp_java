package metier;

public interface pay {
    public void verser(int sum);
    public void retirer(int amount);
}
