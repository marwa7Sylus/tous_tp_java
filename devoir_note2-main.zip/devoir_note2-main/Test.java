package Social_media;

public class Test {
    public static void main(String[] args) {
        new EXEMPLE();
    }
}

